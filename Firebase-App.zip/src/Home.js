import React, { Component } from 'react'; 

class Home extends Component {
  render() {
    return (
      <div className="Home">
        <h1>Welcome to the homepage!</h1>
        <p>You don’t need to be logged in to see this page.</p>
      </div>
    );
  }
}

export default Home;
